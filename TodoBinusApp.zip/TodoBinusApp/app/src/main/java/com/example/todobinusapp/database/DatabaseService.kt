package com.example.todobinusapp.database

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [TaskModel::class],
    exportSchema = false,
    version = 1
)

// misal nambahin enyity atau dao baru maka akan terus nambah kebawah
abstract class DatabaseService: RoomDatabase() {
    abstract fun taskDao(): TaskDao
}